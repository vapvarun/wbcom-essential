<?php
/**
 * Template Library Header Tabs.
 *
 * @link       https://wbcomdesigns.com/plugins
 * @since      1.0.0
 *
 * @package    Wbcom_Essential
 * @subpackage Wbcom_Essential/plugins/elementor/scripts
 */

?>
<div id="wbcom-essential-modal-tabs-items"></div>
