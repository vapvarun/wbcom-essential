<?php
/**
 * Templates Loader error.
 *
 * @link       https://wbcomdesigns.com/plugins
 * @since      1.0.0
 *
 * @package    Wbcom_Essential
 * @subpackage Wbcom_Essential/plugins/elementor/templates/scripts
 */

?>
<div class="wbcomessentialelementor-template-modal-error">
</div>
